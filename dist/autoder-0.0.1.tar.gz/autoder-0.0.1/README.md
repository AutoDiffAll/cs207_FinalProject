# cs207-FinalProject

[![Build Status](https://travis-ci.org/AutoDiffAll/cs207_FinalProject.svg?branch=master)](https://travis-ci.org/AutoDiffAll/cs207_FinalProject.svg?branch=master)

[![Coverage Status](https://coveralls.io/repos/github/AutoDiffAll/cs207_FinalProject/badge.svg?branch=master)](https://coveralls.io/github/AutoDiffAll/cs207_FinalProject?branch=master)

Final Project to create a general Auto Differentiation Class

cs207-FinalProject
Group name: Team non-CS majors

Group number: 5

Members: Josh Feldman, Yuting Kou, Ong Sheng Siong, Eun Seuk Choi
<<<<<<< HEAD

=======
>>>>>>> 5076489ffcb5b9e10ed68feac0b51806c07cf5f6
