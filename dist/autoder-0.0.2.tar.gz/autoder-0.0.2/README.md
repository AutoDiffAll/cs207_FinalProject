# cs207-FinalProject

[![Build Status](https://travis-ci.org/AutoDiffAll/cs207_FinalProject.svg?branch=master)](https://travis-ci.org/AutoDiffAll/cs207_FinalProject)

[![Coverage Status](https://coveralls.io/repos/github/AutoDiffAll/cs207_FinalProject/badge.svg?branch=master)](https://coveralls.io/github/AutoDiffAll/cs207_FinalProject?branch=master)

Final Project to create a general Auto Differentiation Class

cs207-FinalProject
Group name: Team non-CS majors

Group number: 5

Members: Josh Feldman, Yuting Kou, Ong Sheng Siong, Eun Seuk Choi
